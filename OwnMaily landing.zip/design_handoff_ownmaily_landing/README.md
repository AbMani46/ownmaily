# Handoff: OwnMaily Landing Page

## Overview

This is the design reference for the OwnMaily marketing landing page at `ownmaily.com`. It covers the full single-page layout: nav, hero, why section, how it works, features grid, pricing, and footer.

The landing page's core job is to communicate a philosophy — not a feature list. The visitor is opting out of monthly email marketing bills forever. Every design decision reinforces honesty, directness, and ownership.

---

## About the Design Files

The file `OwnMaily Landing.html` in this bundle is a **high-fidelity design reference built in plain HTML/CSS**. It is a prototype showing the intended look, layout, copy, and structure — not production code to ship directly.

Your task is to **recreate this design in the existing Astro codebase** (`AbMani46/Ownmaily-landing`) using its established patterns: Astro components, Tailwind CSS (v4 via `@tailwindcss/vite`), and the existing `global.css` design tokens. Do not copy the HTML file into the Astro project as-is.

The repo already has:
- `src/styles/global.css` — CSS custom properties (design tokens)
- `src/pages/api/checkout.ts` — Stripe checkout endpoint
- `src/pages/api/webhook.ts` — Stripe webhook handler
- `astro.config.mjs` — Node SSR adapter + Tailwind

---

## Fidelity

**High-fidelity.** Recreate pixel-precisely: exact colors, font sizes, font weights, spacing, border radii, hover states, and copy. Every value is documented below.

---

## Design Tokens

These are already in `src/styles/global.css` and should be used as CSS custom properties throughout:

```css
--bg:               #09090b;
--surface:          #111116;
--surface-raised:   #18181f;
--border:           rgba(255,255,255,0.07);
--border-accent:    rgba(16,185,129,0.28);
--text-primary:     #f0f0f2;
--text-secondary:   #8a8a9a;
--text-dim:         #52525f;
--accent:           #10b981;       /* emerald green */
--accent-hover:     #0ea271;
--accent-dim:       rgba(16,185,129,0.10);
--accent-glow:      rgba(16,185,129,0.05);
--font-sans:        'DM Sans', system-ui, sans-serif;
--font-mono:        'DM Mono', 'Fira Code', monospace;
```

**Fonts:** Load from Google Fonts in the `<head>`:
```
DM Sans — weights 300, 400, 500, 600, 700 (opsz 9..40), italic 400
DM Mono — weights 400, 500
```

---

## Layout System

- **Max content width:** 1100px, centered, `padding: 0 32px` (mobile: `0 20px`)
- **Section vertical padding:** 120px top and bottom (mobile: 72px)
- **Horizontal dividers:** `1px solid rgba(255,255,255,0.07)` between every section

---

## Screens / Views

### 1. Navigation

**Sticky** — `position: sticky; top: 0; z-index: 50`  
**Background:** `rgba(9,9,11,0.88)` with `backdrop-filter: blur(12px)`  
**Border bottom:** `1px solid var(--border)`  
**Padding:** `18px 0`

**Layout:** flex row, `justify-content: space-between`, `align-items: center`

**Wordmark (left):**
- Font: DM Sans, 17px, weight 600, `letter-spacing: -0.02em`
- Color: `var(--text-primary)`
- Preceded by a 7×7px circle, `border-radius: 50%`, color `var(--accent)` — acts as a logo dot

**Nav links (right):**
- Font: DM Sans, 14px, color `var(--text-secondary)`
- Hover: `var(--text-primary)`, transition 0.15s
- Links: Why, How it works, Features, Pricing, GitHub, Support the project
- Gap between links: 28px
- "Support the project" link is styled as a pill button:
  - Color: `var(--accent)`
  - Border: `1px solid var(--border-accent)`
  - Padding: `7px 16px`
  - Border-radius: 6px
  - Font size: 13.5px, weight 500
  - Hover bg: `var(--accent-dim)`

---

### 2. Hero

**Padding:** `110px 0 90px`  
**Background:** subtle radial glow — `radial-gradient(ellipse at center, rgba(16,185,129,0.07) 0%, transparent 70%)` positioned at top center, 700×400px, `pointer-events: none`

**Label pill (above headline):**
- Font: DM Mono, 12px, `letter-spacing: 0.04em`, color `var(--accent)`
- Background: `var(--accent-dim)`, border: `1px solid var(--border-accent)`
- Border-radius: 100px, padding `5px 12px`
- Contains a 5×5px pulsing dot (green) + text: `MIT licensed — free to self-host`
- Dot animation: opacity pulses 1 → 0.4 → 1 over 2s ease-in-out, infinite
- Margin-bottom: 32px

**Headline (`<h1>`):**
- Font: DM Sans, `clamp(40px, 6vw, 72px)`, weight 700, `letter-spacing: -0.04em`, `line-height: 1.05`
- Max-width: 820px
- Copy: `Stop renting your` (line break) `email list.`
- "email list." is wrapped in `<em>` styled `font-style: normal; color: var(--accent)`
- Margin-bottom: 24px

**Subheadline:**
- Font: DM Sans, `clamp(16px, 2vw, 19px)`, weight 400, `line-height: 1.65`
- Color: `var(--text-secondary)`
- Max-width: 560px
- Copy: `OwnMaily is self-hosted email marketing. Your subscribers, your server, your data. No per-contact tiers, no monthly fee that grows as you do, no platform risk.`
- Margin-bottom: 44px

**CTA row:**
- Flex row, `align-items: center`, `gap: 24px`, `flex-wrap: wrap`
- Margin-bottom: 60px

**Primary button ("Support the project — $49"):**
- Links to `/api/checkout` (POST form or JS redirect — note: the existing `checkout.ts` expects a POST to `/api/checkout`)
- Background: `var(--accent)`, color: `#021a0f`
- Font: DM Sans, 15px, weight 600, `letter-spacing: -0.01em`
- Padding: `13px 26px`, border-radius: 8px
- Inline heart SVG icon (16×16) before text
- Hover: `background: var(--accent-hover)`, `transform: translateY(-1px)`, transition 0.15s
- Note: In Astro, wrap in a `<form method="POST" action="/api/checkout">` with a `<button type="submit">` for the server route to work

**Ghost button ("Self-host for free"):**
- Links to GitHub repo (external, `target="_blank"`)
- Color: `var(--text-secondary)`, background: none
- Font: DM Sans, 15px, weight 400
- Padding: `13px 0`
- Hover: `color: var(--text-primary)`
- Trailing arrow SVG icon (14×14)

**Proof strip:**
- Flex row, `gap: 20px`, `flex-wrap: wrap`
- Four items: "Unlimited subscribers", "No recurring fees, ever", "Your data, your server", "MIT license"
- Each item: flex row, `gap: 7px`, 13px font, color `var(--text-dim)`
- Each has a small checkmark SVG (14×14) in `var(--accent)` before the text
- Separated by `1px solid var(--border)` vertical dividers (1px wide, 14px tall)

**Terminal block:**
- Max-width: 680px, margin-top: 60px
- Background: `var(--surface)`, border: `1px solid var(--border)`, border-radius: 10px
- **Title bar:** padding `12px 16px`, bg `var(--surface-raised)`, border-bottom `1px solid var(--border)`
  - Three traffic-light dots: red `#ff5f57`, yellow `#ffbd2e`, green `#28c840` — each 11×11px circles, gap 7px
  - Label "install.sh" in DM Mono 11px, `var(--text-dim)`, margin-left 8px
- **Body:** padding `20px 22px`, DM Mono 13.5px, line-height 1.8
  - Line 1: dim comment — `# One command to install`
  - Line 2: green prompt `$` + primary text command `curl https://ownmaily.com/install.sh | bash`
  - Blank gap (8px margin-top)
  - Lines 3–4: secondary text — `Pulling Docker image...` / `Starting services...`
  - Gap (4px margin-top)
  - Line 5: accent green — `OwnMaily running at http://localhost:4400`
  - Gap (4px margin-top)
  - Line 6: dim comment — `# Complete setup wizard, connect your SMTP, send.`

---

### 3. Why Section

**Section label:** DM Mono, 11.5px, `letter-spacing: 0.1em`, uppercase, color `var(--accent)`, margin-bottom 16px. Text: `Why OwnMaily`

**Title:** `clamp(28px, 4vw, 42px)`, weight 700, `letter-spacing: -0.03em`, `line-height: 1.1`. Copy: `Monthly email pricing is broken.`

**Body paragraph:** 17px, `var(--text-secondary)`, `line-height: 1.7`, max-width 600px.  
Copy: `You pay more as you grow. The tool that should reward your success punishes it. Mailchimp charges $350/month at 50k subscribers. ConvertKit is $290. These are recurring fees for software that does not get 3x better each year. You are renting a list you built yourself.`

**2×2 grid:**
- `display: grid; grid-template-columns: 1fr 1fr; gap: 60px 80px; margin-top: 60px`
- Mobile: single column, gap 40px

Each grid item:
- **Number label:** DM Mono, 11px, `var(--text-dim)`, `letter-spacing: 0.08em`, margin-bottom 12px. Values: `01`, `02`, `03`, `04`
- **Title:** 19px, weight 600, `letter-spacing: -0.02em`, margin-bottom 10px
- **Body:** 15px, `var(--text-secondary)`, `line-height: 1.7`

Content:
1. `You own the data.` — `Your subscriber list lives in your Postgres database, on your server. Not exported, not synced, not held hostage. If you stop using OwnMaily tomorrow, your data is already yours.`
2. `One less subscription.` — `Indie founders and bootstrappers carry a stack of monthly bills. Email marketing is usually one of the biggest. OwnMaily replaces it with a server cost you were probably already paying.`
3. `No platform risk.` — `Platforms change pricing, deprecate features, or shut down. When your list is self-hosted and MIT licensed, none of that applies to you. Fork it if you want to.`
4. `Bring your own SMTP.` — `Connect Resend, Mailgun, or Amazon SES. OwnMaily handles the queue, tracking, and bounce handling. Your SMTP provider just sends the mail. Switch providers any time, no re-imports.`

**Callout box (below grid):**
- Margin-top: 64px, padding: `28px 32px`
- Background: `var(--accent-dim)`, border: `1px solid var(--border-accent)`, border-radius: 10px
- Flex row, `align-items: flex-start`, gap 18px
- Left: info circle SVG icon (20×20) in `#10b981`, flex-shrink 0, margin-top 2px
- Right: 15px text, `var(--text-secondary)`, `line-height: 1.65`
- **Bold lead:** `Who this is for:` — `var(--text-primary)`, weight 500
- Copy: `Indie founders, bootstrappers, solo newsletter operators, and anyone running a small business who thinks paying $50/month for software that sends emails is absurd. If you are comfortable running a Docker container, OwnMaily is for you. If you are not, the one-click Railway or Render deploy takes five minutes.`

---

### 4. How It Works

**Section label:** `How it works`  
**Title:** `Two ways to get running.`  
**Body:** `Pick the path that fits how you work. Both end in the same place: your own OwnMaily instance, ready to send.`

**Two-column card grid:**
- `display: grid; grid-template-columns: 1fr 1fr; gap: 32px; margin-top: 52px`
- Mobile: single column

**Each card:**
- Background: `var(--surface)`, border: `1px solid var(--border)`, border-radius: 12px, padding: 32px
- Top edge highlight: `::before` pseudo-element, 1px height, `linear-gradient(90deg, transparent, var(--border-accent), transparent)`
- **Tag pill:** DM Mono, 11px, color `var(--accent)`, bg `var(--accent-dim)`, border `1px solid var(--border-accent)`, border-radius 100px, padding `3px 10px`, margin-bottom 20px, `letter-spacing: 0.04em`
- **Card title:** 20px, weight 600, `letter-spacing: -0.02em`, margin-bottom 14px

**Steps list:** flex column, no gap. Each step:
- Flex row, `align-items: flex-start`, gap 14px, padding `14px 0`
- Border-bottom: `1px solid var(--border)` (last step: none)
- **Number:** DM Mono, 11px, `var(--text-dim)`, flex-shrink 0, margin-top 3px, width 18px
- **Text:** 14.5px, `var(--text-secondary)`, `line-height: 1.55`
- Inline `<code>` elements: DM Mono 12.5px, `var(--accent)`, bg `var(--accent-dim)`, padding `1px 5px`, border-radius 3px
- `<strong>` elements: `var(--text-primary)`, weight 500

**Card 1 — CLI install** (tag: `Terminal users`):
1. Run `curl https://ownmaily.com/install.sh | bash`. Docker and Docker Compose are pulled automatically if missing.
2. A `.env` with a random secret is created and the stack starts. OwnMaily is live on port 4400.
3. Open the setup wizard in your browser. Set your SMTP credentials (Resend, Mailgun, or SES), send yourself a test email.
4. **Done.** Import your first list or drop in the signup embed. You are sending.

**Card 2 — One-click deploy** (tag: `No terminal`):
1. Click the **Deploy on Railway** or **Deploy on Render** button in the GitHub README.
2. The platform clones the repo, provisions Postgres, and starts the app. No config required to get it running.
3. Open your deployment URL. Complete the setup wizard: SMTP credentials, sender name, test email.
4. **Done.** You have a fully managed OwnMaily instance. Railway/Render handle uptime and backups.

---

### 5. Features

**Section label:** `Features`  
**Title:** `Everything you need. Nothing you don't.`  
**Body:** `Built for the actual job: send campaigns to your list, track opens and clicks, manage bounces, grow your subscribers.`

**3×2 grid (6 cells):**
- `display: grid; grid-template-columns: repeat(3, 1fr)`
- Cells separated by `1px` gaps in `var(--border)` color — achieved with `background: var(--border)` on the grid, `gap: 1px`
- Outer border: `1px solid var(--border)`, border-radius: 12px, `overflow: hidden`
- Margin-top: 52px
- Mobile: 2 columns; very small screens: 1 column

**Each cell:**
- Background: `var(--bg)`, padding: `28px 28px 32px`
- Hover: background `var(--surface)`, transition 0.15s

**Icon container (per cell):**
- 36×36px, flex center
- Background: `var(--accent-dim)`, border: `1px solid var(--border-accent)`, border-radius: 8px
- Color: `var(--accent)`, margin-bottom: 16px
- SVG icons: 18×18, stroke-based, stroke-width 2, stroke-linecap/linejoin round

**Feature title:** 15px, weight 600, `letter-spacing: -0.01em`, margin-bottom: 7px  
**Feature desc:** 13.5px, `var(--text-secondary)`, `line-height: 1.6`

**Six features (in order, left to right, top to bottom):**
1. **Unlimited subscribers** — Icon: two people (group). `No tiers. No contact limits. Grow your list as large as your server handles, which is very large.`
2. **Open and click tracking** — Icon: activity/waveform. `Per-campaign open rates and per-link click counts. Tracking pixel and redirect proxy built in.`
3. **Bounce handling** — Icon: warning triangle. `Hard bounces suppress immediately. Soft bounces retry, then suppress after 3 attempts. Suppression list managed automatically.`
4. **Embeddable signup forms** — Icon: monitor/screen. `Drop a single script tag anywhere. The form renders inline and submits to your instance. Double opt-in optional per list.`
5. **Full REST API** — Icon: code brackets `</>`. `The UI is built entirely on the public API. Use it to integrate OwnMaily with anything: Zapier, your own app, AI agents.`
6. **Lists, tags, segmentation** — Icon: grid/table. `Organize subscribers into lists and tag them however you want. Send campaigns to a list or a tag. CSV import and export.`

---

### 6. Pricing

**Section label:** `Pricing`  
**Title:** `Simple. Honest. Final.`  
**Body:** `There are no tiers, no asterisks, and no annual-plan discount that implies a monthly plan exists. OwnMaily is free software. The $49 is optional support.`

**Two-column card grid:**
- `display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 52px`
- Mobile: single column

**Card 1 — Free (self-hosted):**
- Background: `var(--surface)`, border: `1px solid var(--border)`, border-radius: 14px, padding: 36px
- Tag pill: color `var(--text-dim)`, bg `rgba(255,255,255,0.04)`, border `1px solid var(--border)`. Text: `Self-hosted`
- Price: 48px, weight 700, `letter-spacing: -0.04em`, `line-height: 1`. Text: `$0`
- Price note: DM Mono 13px, `var(--text-dim)`. Text: `forever, no card required`
- Title: 19px, weight 600, `letter-spacing: -0.02em`. Text: `Free to self-host`
- Description: 14.5px, `var(--text-secondary)`, `line-height: 1.65`. Copy: `Clone the repo, run Docker Compose, done. MIT licensed. Nothing is locked, nothing expires. OwnMaily is free software.`
- Three bullet items (checkmark SVG + text, 14px, `var(--text-secondary)`):
  - All features, no limits
  - MIT license
  - Community support via GitHub Issues
- Ghost button: `Get the code on GitHub` with trailing arrow → `https://github.com/AbMani46/ownmaily`

**Card 2 — Support ($49) — FEATURED:**
- Background: `var(--surface-raised)`, border: `1px solid var(--border-accent)`, border-radius: 14px, padding: 36px
- Subtle top glow: `::after` `radial-gradient(ellipse at 50% 0%, rgba(16,185,129,0.06) 0%, transparent 65%)`
- Tag pill: color `var(--accent)`, bg `var(--accent-dim)`, border `1px solid var(--border-accent)`. Text: `One-time payment`
- Price: 48px, weight 700, color `var(--accent)`. Text: `$49`
- Price note: DM Mono 13px, `var(--text-secondary)`. Text: `one time, tax included, no renewal`
- Title: `Support the project`
- Description: `You are not buying a license. You are backing the idea that software you host yourself should not cost you a recurring fee. This keeps OwnMaily maintained and independent.`
- Three bullet items:
  - Everything in the free tier
  - Priority GitHub Issues response
  - You back an indie tool staying independent
- **Primary button (full width):** `Support the project` with heart icon → `/api/checkout`
  - In Astro, use `<form method="POST" action="/api/checkout"><button type="submit">...</button></form>`
- Disclaimer: DM Mono 12.5px, `var(--text-dim)`. Text: `Stripe payment. Receipt emailed automatically.`

---

### 7. Footer

**Padding:** `48px 0`  
**Border-top:** `1px solid var(--border)`

**Layout:** flex row, `justify-content: space-between`, `align-items: center`, `flex-wrap: wrap`, gap 24px  
Mobile: flex-direction column, align-items flex-start

**Left column (flex column, gap 8px):**

Byline (13px, `var(--text-dim)`, `line-height: 1.6`):  
`Built by Jordan — who also makes ` + link `SolidUptime` (→ `https://soliduptime.org`) + ` (free uptime monitoring) and ` + link `Middl` (→ `https://getmiddl.com`) + ` (free AI-powered freelance workspace).`

Link styles: color `var(--text-secondary)`, `border-bottom: 1px solid var(--border)`, `padding-bottom: 1px`  
Hover: color `var(--text-primary)`, border-color `var(--text-secondary)`

License line (DM Mono, 11.5px, `var(--text-dim)`):  
`MIT` (in `var(--accent)`) ` licensed — ownmaily.com`

**Right column (flex row, gap 20px):**
- `GitHub` → `https://github.com/AbMani46/ownmaily` (external)
- `Contact` → `mailto:jordan@ownmaily.com`
- Both: 13px, `var(--text-dim)`, hover `var(--text-secondary)`

---

## Interactions & Behavior

| Element | Interaction | Detail |
|---|---|---|
| All links/buttons | `transition: 0.15s` | color, background, transform transitions |
| Primary button | Hover | `background: var(--accent-hover)`, `translateY(-1px)` |
| Ghost button | Hover | `color: var(--text-primary)` |
| Nav CTA | Hover | `background: var(--accent-dim)` |
| Feature cells | Hover | `background: var(--surface)` |
| Footer links | Hover | color + border-color change |
| Label dot (hero) | Always | CSS pulse animation, 2s loop |
| Nav | Scroll | Sticky + blur, already handles itself |

**Stripe CTA:** The existing `src/pages/api/checkout.ts` handles `POST /api/checkout` and redirects to Stripe Checkout. The button must submit as a POST. Wrap it:
```astro
<form method="POST" action="/api/checkout">
  <button type="submit" class="btn-primary">
    <!-- heart SVG -->
    Support the project — $49
  </button>
</form>
```

**Anchor links:** All nav links scroll to section IDs: `#why`, `#how`, `#features`, `#pricing`. Use `scroll-behavior: smooth` on `html` (already in `global.css`).

---

## Responsive Breakpoints

| Breakpoint | Changes |
|---|---|
| `max-width: 720px` | Section gap → 72px; container padding → 20px; why grid → 1 col; how cols → 1 col; features → 2 cols; pricing → 1 col; nav links hidden; footer stacks |
| `max-width: 500px` | Features grid → 1 col |

---

## SEO / Head Tags

Add these to the Astro layout `<head>`:

```html
<meta name="description" content="Self-hosted email marketing with no subscriber limits, no monthly fees, and no lock-in. Free to self-host. $49 one-time to support the project." />
<meta property="og:title" content="OwnMaily — Own your email list. No monthly fees." />
<meta property="og:description" content="Self-hosted email marketing. Unlimited subscribers. One-time $49 optional support. Free to self-host forever." />
<meta property="og:image" content="https://ownmaily.com/og.png" />
<meta property="og:url" content="https://ownmaily.com" />
<meta property="og:type" content="website" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="OwnMaily — Own your email list. No monthly fees." />
<meta name="twitter:description" content="Self-hosted email marketing. Unlimited subscribers. One-time $49 optional support. Free to self-host forever." />
<meta name="twitter:image" content="https://ownmaily.com/og.png" />
```

Note: `og.png` does not exist yet — create a simple branded OG image (1200×630) and place it in `public/og.png`.

---

## Suggested Astro File Structure

```
src/
  components/
    Nav.astro
    Hero.astro
    Why.astro
    HowItWorks.astro
    Features.astro
    Pricing.astro
    Footer.astro
  layouts/
    Base.astro       ← head tags, font imports, global.css
  pages/
    index.astro      ← composes all components
    success.astro    ← post-Stripe success page (TODO)
    api/
      checkout.ts    ← already exists
      webhook.ts     ← already exists
```

---

## Assets

| Asset | Status | Notes |
|---|---|---|
| `public/favicon.svg` | Exists in repo | Already there |
| `public/og.png` | Missing | Need to create — 1200×630 branded card |
| Google Fonts (DM Sans, DM Mono) | Load from CDN | Add to `Base.astro` `<head>` |
| SVG icons | Inline in HTML | All icons are inline SVGs — copy from the reference HTML or use Heroicons equivalents |

---

## Files in This Bundle

| File | Purpose |
|---|---|
| `OwnMaily Landing.html` | Full high-fidelity design reference. Open in a browser to see the intended design. |
| `README.md` | This document — implementation spec for Claude Code. |
